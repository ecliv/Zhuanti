// indexof.h

extern "C" {

long IndexOf( long n, long array[], unsigned count );
// Assembly language module
}