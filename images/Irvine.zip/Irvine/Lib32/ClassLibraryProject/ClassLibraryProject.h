// ClassLibraryProject.h

#pragma once

using namespace System;

namespace ClassLibraryProject {

	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
